/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
(function() {

var DropDownMenu = function(itemTexts, buttonText, buttonBG) {
  this.initialize(itemTexts, buttonText, buttonBG);
}
var p = DropDownMenu.prototype = new createjs.Container(); // inherit from Container

p.buttonBackground;
p.buttonText;
p.itemContainer;
p.buttonItems;
p.selectedIndex = 0;

p.Container_initialize = p.initialize;

p.initialize = function(itemTexts, buttonText, buttonBG) {
    this.Container_initialize();
    
    this.buttonBackground = new createjs.Bitmap(buttonBG);
    this.buttonBackground.x = -this.buttonBackground.image.width/2;
    this.buttonBackground.y = -this.buttonBackground.image.height/2 - 2;
    this.buttonText = new createjs.Text();
    this.buttonText.font = '18px avenir_65medium';
    this.buttonText.textAlign = 'center';
    this.buttonText.textBaseline = 'middle';
    this.buttonText.color = "#333333";
    this.buttonText.text = buttonText;

    this.itemContainer = new createjs.Container();
    var bg = new createjs.Shape();
    bg.graphics.beginFill("#FFFFFF");
    bg.graphics.drawRoundRect (-65,-12 + this.buttonBackground.image.height/2,130,itemTexts.length * 26 + this.buttonBackground.image.height/2, 12);
    this.itemContainer.addChild(bg);

    this.addChild(this.itemContainer);
    this.addChild(this.buttonBackground);
    this.addChild(this.buttonText);

    var bindClickedOnItem = this.clickOnItem.bind(this);
    this.buttonItems = new Array();
    for (var i = 0; i < itemTexts.length; i++) {
        this.buttonItems[i] = new DropDownItem(itemTexts[i]);
        this.buttonItems[i].y = this.buttonBackground.image.height/2 + 20 + (i * 26);
        this.itemContainer.addChild(this.buttonItems[i]);
        this.buttonItems[i].on("click", bindClickedOnItem);
    }
    this.itemContainer.visible = false;
    this.on("mouseover", this.handleOver);
    this.on("mouseout", this.handleOut);
        
} ;
p.clickOnItem = function(event) {
    this.itemContainer.visible = false;
    for (var i = 0; i < this.buttonItems.length; i++) {
        if (this.buttonItems[i] == event.target)
        {
            this.selectedIndex = i;
            this.dispatchEvent("valueChanged");
        }
    }
}

p.handleOver = function (event) {       
    this.itemContainer.visible = true;
} ;

p.handleOut = function (event) {    
    this.itemContainer.visible = false;
} ;

window.DropDownMenu = DropDownMenu;
}());