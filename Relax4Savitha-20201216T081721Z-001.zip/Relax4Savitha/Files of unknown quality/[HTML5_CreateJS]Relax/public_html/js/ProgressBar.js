/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
(function() {

var ProgressBar = function(bg, fg, reversed) {
  this.initialize(bg, fg, reversed);
}
var p = ProgressBar.prototype = new createjs.Container(); // inherit from Container

p.bg;
p.fg;
p.reverserd = false;

p.Container_initialize = p.initialize;

p.initialize = function(bg, fg, reversed) {
	this.Container_initialize();
        this.reversed = reversed;
	
        this.bg = new createjs.Bitmap(bg);
	this.fg = new createjs.Bitmap(fg);
        
        this.bg.x = -this.bg.image.width/2;
        this.bg.y = -this.bg.image.height/2;
        
        this.fg.x = -this.fg.image.width/2;
        this.fg.y = -this.fg.image.height/2;
        
	this.addChild(this.bg); 
	this.addChild(this.fg); 
} ;

p.update = function (percent) {       
        this.fg.scaleX = this.reversed ? 1 - percent : percent;
} ;

window.ProgressBar = ProgressBar;
}());