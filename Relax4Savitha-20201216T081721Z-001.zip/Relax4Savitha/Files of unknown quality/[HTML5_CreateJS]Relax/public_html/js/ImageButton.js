/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
(function() {

var ImageButton = function(normalImg, hoverImg) {
  this.initialize(normalImg, hoverImg);
}

var p = ImageButton.prototype = new createjs.Container(); // inherit from Container

p.normalImage;
p.hoverImage;

p.Container_initialize = p.initialize;

p.initialize = function(normalImg, hoverImg) {
	this.Container_initialize();
	
        this.normalImage = new createjs.Bitmap(normalImg);
	this.hoverImage = new createjs.Bitmap(hoverImg);
        
        this.normalImage.x = -this.normalImage.image.width/2;
        this.normalImage.y = -this.normalImage.image.height/2;
        
        this.hoverImage.x = -this.hoverImage.image.width/2;
        this.hoverImage.y = -this.hoverImage.image.height/2;
        
	this.addChild(this.normalImage); 
	this.addChild(this.hoverImage); 
        
        this.on("click", this.handleClicked);
	this.on("mouseover", this.handleOver);
	this.on("mouseout", this.handleOut);

        this.hoverImage.visible = false;
	this.mouseChildren = false;
} ;

p.handleClicked = function (event) {       
        this.dispatchEvent('buttonClicked');
} ;

p.handleOver = function (event) {       
        this.normalImage.visible = false;
        this.hoverImage.visible = true;
} ;

p.handleOut = function (event) {    
        this.normalImage.visible = true;
        this.hoverImage.visible = false;
} ;

window.ImageButton = ImageButton;
}());