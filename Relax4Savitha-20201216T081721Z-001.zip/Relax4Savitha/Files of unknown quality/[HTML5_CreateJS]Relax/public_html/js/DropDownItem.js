/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
(function() {

var DropDownItem = function(text) {
  this.initialize(text);
}
var p = DropDownItem.prototype = new createjs.Container(); // inherit from Container

p.textBlack;
p.background;

p.Container_initialize = p.initialize;

p.initialize = function(text) {
	this.Container_initialize();
        this.background = new createjs.Shape();
        this.background.graphics.beginFill("#ABABAB");
        this.background.graphics.drawRect (-65,-12,130,23);
        this.textBlack = new createjs.Text();
        this.textBlack.font = '18px avenir_65medium';
        this.textBlack.textAlign = 'center';
        this.textBlack.textBaseline = 'middle';
        this.textBlack.color = "#000000";
        this.textBlack.text = text;
        
	this.addChild(this.background); 
	this.addChild(this.textBlack);
        
	this.on("mouseover", this.handleOver);
	this.on("mouseout", this.handleOut);

        this.background.alpha = 0.02;
	this.mouseChildren = false;
} ;

p.handleOver = function (event) {       
        this.background.alpha = 0.7;
} ;

p.handleOut = function (event) {    
        this.background.alpha = 0.02;
} ;

window.DropDownItem = DropDownItem;
}());