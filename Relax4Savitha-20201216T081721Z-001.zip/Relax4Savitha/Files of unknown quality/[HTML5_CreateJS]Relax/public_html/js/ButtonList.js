/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
(function() {

var ButtonList = function(nameList, buttonBgImg, bgImg, useHoverShadow) {
  this.initialize(nameList, buttonBgImg, bgImg, useHoverShadow == 'undefined' ? false : useHoverShadow);
}
var p = ButtonList.prototype = new createjs.Container(); // inherit from Container

p.background;
p.buttonArray;
p.selectedIndex = 0;

p.Container_initialize = p.initialize;

p.initialize = function(nameList, buttonBgImg, bgImg, useHoverShadow) {
    this.background = new createjs.Bitmap(bgImg);
    this.background.x = -this.background.image.width/2;
    this.addChild(this.background);
    
    var bindButtonClicked = this.buttonClicked.bind(this);
    
    this.buttonArray = new Array();
    for (var i = 0; i < nameList.length; i++) {
        this.buttonArray[i] = new StyleTextButton(nameList[i], buttonBgImg, useHoverShadow);
        this.buttonArray[i].y = i * 32 + 30;
        this.buttonArray[i].on("click", bindButtonClicked);
        this.addChild(this.buttonArray[i]);
    }
} ;

p.buttonClicked = function(event) {
    for (var i = 0; i < this.buttonArray.length; i++) {
        if (this.buttonArray[i] == event.target)
        {
            this.selectedIndex = i;
            this.dispatchEvent("selected");
        }
    }
} 

window.ButtonList = ButtonList;
}());