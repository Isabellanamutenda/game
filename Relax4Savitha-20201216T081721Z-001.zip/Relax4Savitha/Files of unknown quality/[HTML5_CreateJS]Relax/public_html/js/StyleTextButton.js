/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
(function() {

var StyleTextButton = function(text, bgImg, useHoverShadow) {
  this.initialize(text, bgImg, useHoverShadow == 'undefined' ? false : useHoverShadow);
}
var p = StyleTextButton.prototype = new createjs.Container(); // inherit from Container

p.textBlack;
p.textWhite;
p.background;
p.useHoverShadow;

p.Container_initialize = p.initialize;

p.initialize = function(text, bgImg, useHoverShadow) {
	this.Container_initialize();
	this.useHoverShadow = useHoverShadow;
        this.background = new createjs.Bitmap(bgImg);
        this.background.x = -this.background.image.width/2;
        this.background.y = -this.background.image.height/2;
        
        this.textBlack = new createjs.Text();
        this.textBlack.font = '24px arial';
        this.textBlack.textAlign = 'center';
        this.textBlack.textBaseline = 'middle';
        this.textBlack.color = "#000000";
        this.textBlack.text = text;
        
        this.textWhite = new createjs.Text();
        this.textWhite.font = '24px arial';
        this.textWhite.textAlign = 'center';
        this.textWhite.textBaseline = 'middle';
        this.textWhite.color = "#FFFFFF";
        this.textWhite.text = text;
        this.textWhite.x = this.textBlack.x + 2;
        this.textWhite.y = this.textBlack.y + 2;
        
	this.addChild(this.background); 
	this.addChild(this.textBlack);
	this.addChild(this.textWhite);
        
	this.on("mouseover", this.handleOver);
	this.on("mouseout", this.handleOut);

        this.background.alpha = 0.02;
        this.textWhite.alpha = 0;
	this.mouseChildren = false;
} ;

p.handleOver = function (event) {       
        this.background.alpha = 1;
        if (this.useHoverShadow) this.textWhite.alpha = 1;
} ;

p.handleOut = function (event) {    
        this.background.alpha = 0.02;
        this.textWhite.alpha = 0;
} ;

window.StyleTextButton = StyleTextButton;
}());