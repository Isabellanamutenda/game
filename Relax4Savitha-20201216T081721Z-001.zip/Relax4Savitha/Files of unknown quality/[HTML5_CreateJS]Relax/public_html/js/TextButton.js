/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
(function() {

var TextButton = function(text, bgImg) {
  this.initialize(text, bgImg);
}
var p = TextButton.prototype = new createjs.Container(); // inherit from Container

p.textBlack;
p.background;

p.Container_initialize = p.initialize;

p.initialize = function(text, bgImg) {
	this.Container_initialize();
        
        this.background = new createjs.Bitmap(bgImg);
        this.background.x = -this.background.image.width/2;
        this.background.y = -this.background.image.height/2 - 2;
        
        this.textBlack = new createjs.Text();
        this.textBlack.font = '20px avenir_65medium';
        this.textBlack.textAlign = 'center';
        this.textBlack.textBaseline = 'middle';
        this.textBlack.color = "#4D4D4D";
        this.textBlack.text = text;
        
	this.addChild(this.background); 
	this.addChild(this.textBlack);
        
	this.on("mouseover", this.handleOver);
	this.on("mouseout", this.handleOut);

	this.mouseChildren = false;
} ;

p.handleOver = function (event) {     
        this.textBlack.color = "#FFFFFF";
} ;

p.handleOut = function (event) {    
        this.textBlack.color = "#4D4D4D";
} ;

window.TextButton = TextButton;
}());