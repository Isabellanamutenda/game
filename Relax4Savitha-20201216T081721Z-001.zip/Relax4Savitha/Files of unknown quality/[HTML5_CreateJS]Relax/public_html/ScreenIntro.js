/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
(function() {

var ScreenIntro = function(resourceQueue) {
  this.initialize(resourceQueue);
}
var p = ScreenIntro.prototype = new createjs.Container(); // inherit from Container

p.bg;
p.playBtn;

p.Container_initialize = p.initialize;

p.initialize = function(resourceQueue) {
    this.Container_initialize();
    
    //Mask
    var shape = new createjs.Shape();
    shape.graphics = new createjs.Graphics().drawRoundRect (0, 0, 636, 477, 24);
    this.mask = shape;
    
    this.bg = new createjs.Bitmap(resourceQueue.getResult("intro"));
    this.bg.setTransform(0, 0, 636/this.bg.image.width, 477/this.bg.image.height);
    this.addChild(this.bg);

    this.playBtn = new ImageButton(resourceQueue.getResult("btnPlay_normal"), resourceQueue.getResult("btnPlay_hover"));
    this.playBtn.x = 523;
    this.playBtn.y = 400;
    this.addChild(this.playBtn);
    
    var bindedPlayClicked = this.playClicked.bind(this);
    this.playBtn.on("click", bindedPlayClicked);
};

p.playClicked = function (event) {    
    this.dispatchEvent("closeIntroScreen");
};

window.ScreenIntro = ScreenIntro;
}());

