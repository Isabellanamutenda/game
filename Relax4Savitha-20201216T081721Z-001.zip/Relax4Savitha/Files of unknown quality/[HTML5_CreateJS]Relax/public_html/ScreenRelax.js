/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
(function() {

var ScreenRelax = function(resourceQueue, soundId, duration, displayTimer, useBell, isResourceLoaded) {
  this.initialize(resourceQueue, soundId, duration, displayTimer, useBell,isResourceLoaded);
}
var p = ScreenRelax.prototype = new createjs.Container(); // inherit from Container


p.bg;
p.progressBar;
p.loadingTextFrame;
p.viewingTextFrame;
p.fullScreenBtn;
p.queue;

p.starTime;
p.duration;
p.displayTimer;
p.useBell;

p.bindedLoadingCompleted;
p.bindedTick;

p.Container_initialize = p.initialize;

p.initialize = function(resourceQueue, soundId, duration, displayTimer, useBell, isResourceLoaded) {
    this.Container_initialize();
    //Mask
    var shape = new createjs.Shape();
    shape.graphics = new createjs.Graphics().drawRoundRect (0, 0, 636, 477, 24);
    this.mask = shape;
    
    this.queue = resourceQueue;
    this.duration = duration * 60 * 1000;
    this.displayTimer = displayTimer;
    this.useBell = useBell;
    
    var blackBg = new createjs.Shape();
    blackBg.graphics.beginFill("#000000");
    blackBg.graphics.drawRect (0,0, 636, 477);
    this.addChild(blackBg);
    
    this.loadingTextFrame = new createjs.Bitmap(resourceQueue.getResult("loadingTextFrame"));
    this.loadingTextFrame.x = (636 - this.loadingTextFrame.image.width) /2;
    this.loadingTextFrame.y = (477 - this.loadingTextFrame.image.height) /2 - 60;
    this.addChild(this.loadingTextFrame);

    this.bindedLoadingCompleted = p.loadingCompleted.bind(this);
    this.bindedTick = p.tick.bind(this);
    
    if(isResourceLoaded) this.loadingCompleted();

     else stage.on("resourceLoaded", this.bindedLoadingCompleted, this);
};

p.loadingCompleted = function (event) {  
    var d = new Date();
    this.starTime = d.getTime();
    
    stage.off("resourceLoaded", this.bindedLoadingCompleted);
    this.queue.removeAllEventListeners();
    this.loadingTextFrame.visible = false;
    
    this.bg = new createjs.Bitmap(this.queue.getResult("relaxBg"));
    this.bg.scaleX = 636/this.bg.image.width;
    this.bg.scaleY = 477/this.bg.image.height;
    this.addChild(this.bg);
    
    this.progressBar = new ProgressBar(this.queue.getResult("progressBarBg"), this.queue.getResult("progressBarFore"), true);
    this.progressBar.x = 490;
    this.progressBar.y = 430;
    this.addChild(this.progressBar);
    this.progressBar.visible = this.displayTimer;
    
    this.fullScreenBtn = new ImageButton(this.queue.getResult("fullScreenBtn_normal"), this.queue.getResult("fullScreenBtn_hover"));
    this.fullScreenBtn.x = 45;
    this.fullScreenBtn.y = 430;
    this.addChild(this.fullScreenBtn);
    
    var bindedFullScreenClicked = this.fullScreenClicked.bind(this);
    this.fullScreenBtn.on("click", bindedFullScreenClicked);
    
    createjs.Sound.play("relaxSound", createjs.Sound.INTERRUPT_ANY, 0, 0, -1, 1, 0);
    this.on('tick', this.bindedTick);
};

p.fullScreenClicked = function(event) {
    var elem = document.getElementById("demoCanvas");
    if (!document.fullscreenElement &&    // alternative standard method
      !document.mozFullScreenElement && !document.webkitFullscreenElement && !document.msFullscreenElement ) {  // current working methods
    if (elem.requestFullscreen) {
      elem.requestFullscreen();
    } else if (elem.msRequestFullscreen) {
      elem.documentElement.msRequestFullscreen();
    } else if (elem.mozRequestFullScreen) {
      elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullscreen) {
      elem.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
    }
  } else {
    if (document.exitFullscreen) {
      document.exitFullscreen();
    } else if (document.msExitFullscreen) {
      document.msExitFullscreen();
    } else if (document.mozCancelFullScreen) {
      document.mozCancelFullScreen();
    } else if (document.webkitExitFullscreen) {
      document.webkitExitFullscreen();
    }
  }
}

p.tick = function(event) {
    var d = new Date();
    this.progressBar.update((d.getTime() - this.starTime)/ this.duration);
    if (this.starTime + this.duration <= d.getTime())
    {
        this.off('tick', this.bindedTick);
        createjs.Sound.stop();
        if (this.useBell) 
            createjs.Sound.play("soundBell")
        this.dispatchEvent("timeUp");
        this.removeAllEventListeners();
    }
};

window.ScreenRelax = ScreenRelax;
}());

