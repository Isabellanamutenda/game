/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
(function() {

var ScreenMainMenu = function(resourceQueue) {
  this.initialize(resourceQueue);
}
var p = ScreenMainMenu.prototype = new createjs.Container(); // inherit from Container

//General
p.bg;
p.copyrightBg;
p.copyrightText;

//Tittle Screen
p.title;
p.instructionBtn;
p.playBtn;
p.instructionFrame;

//Sound Choosing
p.soundChoosingTitle;
p.soundList;

//Setting Choosing
p.settingChoosingTitle;
p.dropDownDuration;
p.dropDownTimer;
p.dropDownBell;
p.nextBtn;

//Debrief
p.thankTextFrame;
p.playAgainTextFrame;
p.btnPlayAgain;
p.btnChangeGame;

p.soundId = 0;
p.duration = 2; 
p.displayTimer = false; 
p.useBell = false; 

////////////////////INITIALIZE//////////////////////////////////////////////////

p.Container_initialize = p.initialize;
p.initialize = function(resourceQueue) {
    this.Container_initialize();
    //Mask
    var shape = new createjs.Shape();
    shape.graphics = new createjs.Graphics().drawRoundRect (0, 0, 636, 477, 24);
    this.mask = shape;
    
    this.bg = new createjs.Bitmap(resourceQueue.getResult("bg"));
    this.bg.setTransform(0, 0, 636/this.bg.image.width, 477/this.bg.image.height);
    this.addChild(this.bg);
    
    this.title = new createjs.Bitmap(resourceQueue.getResult("gameTitle"));
    this.title.x = 144;
    this.title.y = 30;
    this.addChild(this.title);
    
    this.copyrightBg = new createjs.Bitmap(resourceQueue.getResult("copyrightBg"));
    this.copyrightBg.x = (636 - this.copyrightBg.image.width) / 2 ;
    this.copyrightBg.y = 477 - this.copyrightBg.image.height  - 5;
    this.addChild(this.copyrightBg);
        
    this.copyrightText = new createjs.Text();
    this.copyrightText.font = 'bold 12px Arial';
    this.copyrightText.textAlign = 'center';
    this.copyrightText.textBaseline = 'middle';
    this.copyrightText.color = "#000000";
    this.copyrightText.text = "© 2010-2014 Anti-Aging Games, LLC";
    this.copyrightText.x = 636 / 2 ;
    this.copyrightText.y = this.copyrightBg.y + this.copyrightBg.image.height/2;
    this.addChild(this.copyrightText);
    
    //==============================================
    
    this.instructionBtn = new ImageButton(resourceQueue.getResult("btnInstruction_normal"), resourceQueue.getResult("btnInstruction_hover"));
    this.instructionBtn.x = 200;
    this.instructionBtn.y = 400;
    this.addChild(this.instructionBtn);
    
    this.playBtn = new ImageButton(resourceQueue.getResult("btnPlay_normal"), resourceQueue.getResult("btnPlay_hover"));
    this.playBtn.x = 523;
    this.playBtn.y = 400;
    this.addChild(this.playBtn);
    
    this.instructionFrame = new createjs.Bitmap(resourceQueue.getResult("instructionFrame"));
    this.instructionFrame.x = (636 - this.instructionFrame.image.width) /  2;
    this.instructionFrame.y = 130;
    this.addChild(this.instructionFrame);
    
    //==============================================
    this.soundChoosingTitle = new createjs.Bitmap(resourceQueue.getResult("chooseSound"));
    this.soundChoosingTitle.x = 318 - this.soundChoosingTitle.image.width/2;
    this.soundChoosingTitle.y = 30;
    this.addChild(this.soundChoosingTitle);
    
    this.soundList = new ButtonList(SOUND_LIST, resourceQueue.getResult("styleButtonBg"), resourceQueue.getResult("soundListBg"), true);
    this.soundList.x = 318;
    this.soundList.y = 140;
    this.addChild(this.soundList);
    
    //==============================================
    
    this.settingChoosingTitle = new createjs.Bitmap(resourceQueue.getResult("chooseSettings"));
    this.settingChoosingTitle.x = 318 - this.settingChoosingTitle.image.width/2;
    this.settingChoosingTitle.y = 30;
    this.addChild(this.settingChoosingTitle);
    
    this.dropDownDuration = new DropDownMenu(DURATION_LIST, "Length of Timer?", resourceQueue.getResult("dropDownButtonBg"));
    this.dropDownDuration.x = 636/4;
    this.dropDownDuration.y = 160;
    this.addChild(this.dropDownDuration);
    
    this.dropDownTimer = new DropDownMenu(["Yes", "No"], "Timer?", resourceQueue.getResult("dropDownButtonBg"));
    this.dropDownTimer.x = 636/2;
    this.dropDownTimer.y = 160;
    this.addChild(this.dropDownTimer);
    
    this.dropDownBell = new DropDownMenu(["Yes", "No"], "Bell?", resourceQueue.getResult("dropDownButtonBg"));
    this.dropDownBell.x = 636/4 *3;
    this.dropDownBell.y = 160;
    this.addChild(this.dropDownBell);
    
    this.nextBtn = new TextButton("Next", resourceQueue.getResult("dropDownButtonBg"));
    this.nextBtn.x = 636/2;
    this.nextBtn.y = 400;
    this.addChild(this.nextBtn);
    
    //==============================================
    
    this.thankTextFrame = new createjs.Bitmap(resourceQueue.getResult("thankTextDebrief"));
    this.thankTextFrame.x = (636 - this.thankTextFrame.image.width)/2;
    this.thankTextFrame.y = 100;
    this.addChild(this.thankTextFrame);
    
    this.playAgainTextFrame = new createjs.Bitmap(resourceQueue.getResult("moreGameTextDebrief"));
    this.playAgainTextFrame.x =(636 - this.playAgainTextFrame.image.width)/2;
    this.playAgainTextFrame.y = 340;
    this.addChild(this.playAgainTextFrame);
    
    this.btnPlayAgain = new ImageButton(resourceQueue.getResult("btnPlayAgain_normal"), resourceQueue.getResult("btnPlayAgain_hover"));
    this.btnPlayAgain.x = 636/4;
    this.btnPlayAgain.y = 430;
    this.addChild(this.btnPlayAgain);
    
    this.btnChangeGame = new ImageButton(resourceQueue.getResult("btnChange_normal"), resourceQueue.getResult("btnChange_hover"));
    this.btnChangeGame.x = 636/4 * 3;
    this.btnChangeGame.y = 430;
    this.addChild(this.btnChangeGame);
    
    //==============================================
    
    //Children Events
    var bindedPlayClicked = this.playClicked.bind(this);
    var bindedTooleInstructionClicked = this.tooleInstructionClicked.bind(this);
    var bindedSoundSelected = this.soundSelected.bind(this);
    var bindedSettingDone = this.settingDone.bind(this);
    var bindedPlayAgain = this.playAgain.bind(this);
    var bindedDurationValueChanged = this.durationValueChanged.bind(this);
    var bindedTimerDisplayValueChanged = this.timerDisplayValueChanged.bind(this);
    var bindedBellValueChanged = this.bellValueChanged.bind(this);
    
    this.playBtn.on("click", bindedPlayClicked);
    this.instructionBtn.on("click", bindedTooleInstructionClicked);
    this.soundList.on("selected", bindedSoundSelected);
    this.nextBtn.on("click", bindedSettingDone);
    this.btnPlayAgain.on("click", bindedPlayAgain);
    this.dropDownDuration.on("valueChanged", bindedDurationValueChanged);
    this.dropDownTimer.on("valueChanged", bindedTimerDisplayValueChanged);
    this.dropDownBell.on("valueChanged", bindedBellValueChanged);
    /////////////
    
    this.hideAll();
    this.switchToTitleScreen();
}

////////////////////EVENT HANDLER///////////////////////////////////////////////

p.playClicked = function (event) {    
    this.switchToChooseSound();
}

p.tooleInstructionClicked = function (event) {    
    this.instructionFrame.visible = !this.instructionFrame.isVisible();
}

p.soundSelected = function (event) {    
    this.soundId = this.soundList.selectedIndex;
    this.dispatchEvent("soundSelected");
    this.switchToChooseSettings();
}

p.settingDone = function (event) {
    this.dispatchEvent("choseSettings");
}

p.playAgain = function() {
    this.hideAll();
    this.switchToChooseSound();
}

p.durationValueChanged = function (event) {
    this.duration = DURATION_LIST_MS[this.dropDownDuration.selectedIndex];
}

p.timerDisplayValueChanged = function (event) {
    this.displayTimer = this.dropDownTimer.selectedIndex == 0 ? true : false;
}

p.bellValueChanged = function (event) {
    this.useBell = this.dropDownBell.selectedIndex == 0 ? true : false;
}

// Flow Event ////////////////////////////////////////
p.hideAll = function() {
    //Title Screen
    this.title.visible = false;
    this.instructionBtn.visible = false;
    this.playBtn.visible = false;
    this.instructionFrame.visible = false;

    //Sound Choosing
    this.soundChoosingTitle.visible = false;
    this.soundList.visible = false;

    //Setting Choosing
    this.settingChoosingTitle.visible = false;
    this.dropDownDuration.visible = false;
    this.dropDownTimer.visible = false;
    this.dropDownBell.visible = false;
    this.nextBtn.visible = false;
    
    //Debrief
    this.thankTextFrame.visible = false;
    this.playAgainTextFrame.visible = false;
    this.btnPlayAgain.visible = false;
    this.btnChangeGame.visible = false;
}

p.switchToTitleScreen = function () {
    //Title Screen
    this.title.visible = true;
    this.instructionBtn.visible = true;
    this.playBtn.visible = true;
}

p.switchToChooseSound = function (event) {    
    //Tittle Screen
    this.title.visible = false;
    this.instructionBtn.visible = false;
    this.playBtn.visible = false;
    this.instructionFrame.visible = false;

    //Sound Choosing
    this.soundChoosingTitle.visible = true;
    this.soundList.visible = true;
}

p.switchToChooseSettings = function (event) {    

    //Sound Choosing
    this.soundChoosingTitle.visible = false;
    this.soundList.visible = false;

    //Setting Choosing
    this.settingChoosingTitle.visible = true;
    this.dropDownDuration.visible = true;
    this.dropDownTimer.visible = true;
    this.dropDownBell.visible = true;
    this.nextBtn.visible = true;
}

p.switchToDebrief = function() {
    //Setting Choosing
    this.settingChoosingTitle.visible = false;
    this.dropDownDuration.visible = false;
    this.dropDownTimer.visible = false;
    this.dropDownBell.visible = false;
    this.nextBtn.visible = false;
    
    this.copyrightText.visible = false;
    this.copyrightBg.visible = false;
    
    this.thankTextFrame.visible = true;
    this.playAgainTextFrame.visible = true;
    this.btnPlayAgain.visible = true;
    this.btnChangeGame.visible = true;
}

////////////////////ANIM EVENTS///////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
window.ScreenMainMenu = ScreenMainMenu;
}());

